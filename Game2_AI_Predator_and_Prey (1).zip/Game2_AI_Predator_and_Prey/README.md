# AI Predator & Prey (Minimax + Alpha-Beta Pruning)
PyCharm: File > Open this folder > run `pip install pygame` > right-click main.py > Run.
Controls: Arrows/WASD move the mouse, SPACE wait, M = Human vs AI / AI vs AI, P = alpha-beta on/off,
+ / - = search depth, T = AI speed, R new map, N restart, C screenshot, ESC quit.
Screenshots are saved to the screenshots/ folder. AI code: minimax_ai.py. Report: AI_Games_Report.docx
