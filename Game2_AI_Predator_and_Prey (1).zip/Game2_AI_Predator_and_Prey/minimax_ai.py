"""
minimax_ai.py  -  the "brain" of the AI Predator & Prey game (no pygame code here).

Two-player, turn-based, zero-sum game:
    PREDATOR (MAX)  wants to catch the prey
    PREY     (MIN)  wants to eat all the cheese without being caught

The AI picks moves with MINIMAX, optionally sped up with ALPHA-BETA PRUNING.
A game state is   (predator_cell, prey_cell, cheese_mask).
"""
import random
import time
from collections import deque

INF = 10 ** 9
WIN_SCORE = 10000
SPRINT_EVERY = 5        # every 5th predator move is a 2-cell "sprint"


class PursuitModel:
    def __init__(self, rows, cols, walls, cheese_cells):
        self.rows, self.cols = rows, cols
        self.walls = set(walls)
        self.cells = [(r, c) for r in range(rows) for c in range(cols) if (r, c) not in self.walls]
        self.index = {cell: i for i, cell in enumerate(self.cells)}
        self.adj = [[] for _ in self.cells]
        for cell, i in self.index.items():
            r, c = cell
            for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                nb = (r + dr, c + dc)
                if nb in self.index:
                    self.adj[i].append(self.index[nb])
        # moves = stay or step to a neighbour
        self.moves = [[i] + self.adj[i] for i in range(len(self.cells))]
        # sprint moves = every cell reachable in at most 2 steps (stay, 1 step or 2 steps)
        self.sprint_moves = []
        for i in range(len(self.cells)):
            reach = {i}
            for a in self.adj[i]:
                reach.add(a)
                reach.update(self.adj[a])
            self.sprint_moves.append(sorted(reach))
        self.dist = [self._bfs(i) for i in range(len(self.cells))]
        self.cheese = [self.index[c] for c in cheese_cells]
        self.full_mask = (1 << len(self.cheese)) - 1
        # statistics of the last search
        self.nodes = 0
        self.cutoffs = 0

    def _bfs(self, src):
        d = [999] * len(self.cells)
        d[src] = 0
        q = deque([src])
        while q:
            cur = q.popleft()
            for nb in self.adj[cur]:
                if d[nb] == 999:
                    d[nb] = d[cur] + 1
                    q.append(nb)
        return d

    # --------------------------------------------------------------- helpers
    def eat(self, prey, mask):
        """If the prey stands on cheese, remove that cheese from the mask."""
        for i, cell in enumerate(self.cheese):
            if cell == prey and mask & (1 << i):
                return mask & ~(1 << i)
        return mask

    def remaining(self, mask):
        return [self.cheese[i] for i in range(len(self.cheese)) if mask & (1 << i)]

    # ----------------------------------------------------- evaluation function
    def evaluate(self, pred, prey, mask):
        """
        Heuristic score from the PREDATOR's point of view (higher = better for predator).
          - being close to the prey is good            (-10 * distance)
          - prey stuck in a dead end is good           (+3 per blocked side)
          - every cheese the prey ate is bad           (-40 each)
          - prey far from the remaining cheese is good (+2 * distance to nearest cheese)
        """
        score = -10 * self.dist[pred][prey]
        score += 3 * (4 - len(self.adj[prey]))
        left = self.remaining(mask)
        score -= 40 * (len(self.cheese) - len(left))
        if left:
            score += 2 * min(self.dist[prey][ch] for ch in left)
        return score

    # --------------------------------------------------------------- minimax
    def minimax(self, pred, prey, mask, depth, alpha, beta, pred_turn, prune, tick=0):
        self.nodes += 1
        if pred == prey:
            return WIN_SCORE + depth * 10        # caught - the sooner the better
        if mask == 0:
            return -WIN_SCORE - depth * 10       # prey ate everything
        if depth == 0:
            return self.evaluate(pred, prey, mask)

        if pred_turn:                            # MAX node
            best = -INF
            options = self.sprint_moves[pred] if (tick + 1) % SPRINT_EVERY == 0 else self.moves[pred]
            for m in options:
                v = self.minimax(m, prey, mask, depth - 1, alpha, beta, False, prune, tick + 1)
                if v > best:
                    best = v
                if best > alpha:
                    alpha = best
                if prune and beta <= alpha:
                    self.cutoffs += 1
                    break
            return best
        best = INF                               # MIN node
        for m in self.moves[prey]:
            v = self.minimax(pred, m, self.eat(m, mask), depth - 1, alpha, beta, True, prune, tick)
            if v < best:
                best = v
            if best < beta:
                beta = best
            if prune and beta <= alpha:
                self.cutoffs += 1
                break
        return best

    def choose(self, pred, prey, mask, depth, side, prune=True, tick=0):
        """
        Pick the best move for `side` ('pred' or 'prey').
        Returns a dict with the chosen cell, the score of every candidate move,
        and statistics (nodes visited, branches pruned, time).
        """
        self.nodes = 0
        self.cutoffs = 0
        t0 = time.perf_counter()
        scores = {}
        best_val, best_moves = None, []
        maximizing = side == "pred"
        if maximizing:
            options = self.sprint_moves[pred] if (tick + 1) % SPRINT_EVERY == 0 else self.moves[pred]
        else:
            options = self.moves[prey]
        for m in options:
            if maximizing:
                alpha = -INF if best_val is None else best_val - 1   # -1 keeps ties exact
                v = self.minimax(m, prey, mask, depth - 1, alpha, INF, False, prune, tick + 1)
            else:
                beta = INF if best_val is None else best_val + 1
                v = self.minimax(pred, m, self.eat(m, mask), depth - 1, -INF, beta, True, prune, tick)
            scores[m] = v
            if best_val is None or (maximizing and v > best_val) or (not maximizing and v < best_val):
                best_val, best_moves = v, [m]
            elif v == best_val:
                best_moves.append(m)
        return {
            "move": random.choice(best_moves),
            "value": best_val,
            "scores": scores,
            "nodes": self.nodes,
            "cutoffs": self.cutoffs,
            "ms": (time.perf_counter() - t0) * 1000.0,
            "depth": depth,
            "prune": prune,
        }


def generate_layout(rows, cols, seed=None, n_cheese=5):
    """Random obstacle map; every free cell is connected. Returns walls, pred, prey, cheese."""
    rnd = random.Random(seed)
    while True:
        walls = set()
        for _ in range(20):
            r, c = rnd.randrange(rows), rnd.randrange(cols)
            length = rnd.randint(2, 4)
            dr, dc = rnd.choice([(1, 0), (0, 1)])
            for i in range(length):
                walls.add((r + dr * i, c + dc * i))
        walls = {(r, c) for (r, c) in walls if 0 <= r < rows and 0 <= c < cols}
        free = [(r, c) for r in range(rows) for c in range(cols) if (r, c) not in walls]
        # keep only the biggest connected area (turn tiny pockets into walls)
        seen, best = set(), []
        for cell in free:
            if cell in seen:
                continue
            comp, q = [cell], deque([cell])
            seen.add(cell)
            while q:
                r, c = q.popleft()
                for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    nb = (r + dr, c + dc)
                    if nb in free and nb not in seen and nb not in walls:
                        seen.add(nb)
                        comp.append(nb)
                        q.append(nb)
            if len(comp) > len(best):
                best = comp
        if len(best) < rows * cols * 0.7:
            continue
        keep = set(best)
        walls = {(r, c) for r in range(rows) for c in range(cols) if (r, c) not in keep}
        left = [c for c in keep if c[1] <= cols // 4]
        right = [c for c in keep if c[1] >= cols - 1 - cols // 4]
        if not left or not right:
            continue
        prey, pred = rnd.choice(left), rnd.choice(right)
        rest = [c for c in keep if abs(c[0] - pred[0]) + abs(c[1] - pred[1]) >= 5
                and abs(c[0] - prey[0]) + abs(c[1] - prey[1]) >= 3]
        if len(rest) < n_cheese:
            continue
        cheese = rnd.sample(rest, n_cheese)
        return walls, pred, prey, cheese
