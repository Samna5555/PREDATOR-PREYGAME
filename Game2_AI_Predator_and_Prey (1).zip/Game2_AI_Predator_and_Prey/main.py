"""
AI PREDATOR & PREY  -  Minimax with Alpha-Beta Pruning
Course: Artificial Intelligence  |  Library: Pygame

You are the MOUSE. The AI is the CAT.  Eat all the cheese before the cat catches you.
Run:  python main.py
"""
import os
import sys
import time
import random

import pygame

from minimax_ai import PursuitModel, generate_layout, SPRINT_EVERY

# ------------------------------------------------------------------ settings
TILE = 44
COLS, ROWS = 18, 13
MAP_W, MAP_H = COLS * TILE, ROWS * TILE
PANEL_W, BAR_H = 310, 60
WIDTH, HEIGHT = MAP_W + PANEL_W, MAP_H + BAR_H
FPS = 60
MAX_TURNS = 60

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
SHOT_DIR = os.path.join(BASE_DIR, "screenshots")

C_BG = (24, 26, 34)
C_PANEL = (30, 33, 44)
C_TEXT = (232, 234, 240)
C_DIM = (150, 156, 172)
C_ACCENT = (255, 205, 60)
C_GOOD = (90, 220, 120)
C_BAD = (240, 80, 80)
C_PRED = (255, 130, 60)
C_PREY = (110, 170, 255)

KEY_DIRS = {pygame.K_UP: (-1, 0), pygame.K_w: (-1, 0), pygame.K_DOWN: (1, 0), pygame.K_s: (1, 0),
            pygame.K_LEFT: (0, -1), pygame.K_a: (0, -1), pygame.K_RIGHT: (0, 1), pygame.K_d: (0, 1)}


def load_image(name, size, alpha=True):
    try:
        img = pygame.image.load(os.path.join(ASSET_DIR, name))
        img = img.convert_alpha() if alpha else img.convert()
        return pygame.transform.smoothscale(img, size)
    except Exception:
        return None


class PredatorPreyGame:
    def __init__(self, screen):
        self.screen = screen
        self.f_title = pygame.font.SysFont("arial", 22, bold=True)
        self.f_big = pygame.font.SysFont("arial", 46, bold=True)
        self.f_norm = pygame.font.SysFont("arial", 16)
        self.f_small = pygame.font.SysFont("arial", 14)
        self.f_tag = pygame.font.SysFont("arial", 13, bold=True)

        sz = (TILE, TILE)
        self.img = {
            "floor": load_image("floor.png", sz, False),
            "crate": load_image("crate.png", sz),
            "pred": load_image("predator.png", sz),
            "prey": load_image("prey.png", sz),
            "cheese": load_image("cheese.png", sz),
        }
        self.ov_alt = pygame.Surface(sz, pygame.SRCALPHA)
        self.ov_alt.fill((0, 0, 0, 14))
        self.ov_cand = pygame.Surface(sz, pygame.SRCALPHA)
        self.ov_cand.fill((255, 140, 60, 110))
        self.ov_best = pygame.Surface(sz, pygame.SRCALPHA)
        self.ov_best.fill((80, 240, 120, 130))
        self.ov_danger = pygame.Surface(sz, pygame.SRCALPHA)
        self.ov_danger.fill((255, 50, 50, 70))
        self.grid_surf = pygame.Surface((MAP_W, MAP_H), pygame.SRCALPHA)
        for r in range(ROWS + 1):
            pygame.draw.line(self.grid_surf, (0, 0, 0, 30), (0, r * TILE), (MAP_W, r * TILE))
        for c in range(COLS + 1):
            pygame.draw.line(self.grid_surf, (0, 0, 0, 30), (c * TILE, 0), (c * TILE, MAP_H))
        self.banner = pygame.Surface((MAP_W, 150), pygame.SRCALPHA)
        self.banner.fill((0, 0, 0, 175))

        self.human = True          # True: you play the mouse; False: AI vs AI
        self.prune = True
        self.pred_depth = 4
        self.prey_depth = 4
        self.delay = 420           # ms the AI "shows" its decision before moving
        self.new_map()

    # ------------------------------------------------------------ world setup
    def new_map(self, seed=None):
        self.seed = seed if seed is not None else random.randrange(1, 10 ** 6)
        self.layout = generate_layout(ROWS, COLS, self.seed)
        self.reset()

    def reset(self):
        walls, pred, prey, cheese = self.layout
        self.model = PursuitModel(ROWS, COLS, walls, cheese)
        self.walls = set(walls)
        self.pred = self.model.index[pred]
        self.prey = self.model.index[prey]
        self.mask = self.model.full_mask
        self.n_cheese = len(cheese)
        self.pred_moves = 0          # how many moves the predator has made
        self.turn = 1
        self.state = "PREY"          # PREY / PRED / WIN / LOSE
        self.message = ""
        self.timer = 0
        self.decision = None         # the AI's latest decision (for drawing)
        self.decided = False
        self.log = []
        self.trail_pred, self.trail_prey = [], []
        self.stats = None
        self.say("Game start. Turn 1.")

    def say(self, text):
        self.log.append(text)
        self.log = self.log[-6:]

    def cell(self, i):
        return self.model.cells[i]

    def sprint_next(self):
        return (self.pred_moves + 1) % SPRINT_EVERY == 0

    # ------------------------------------------------------------ game rules
    def apply_prey(self, new):
        self.trail_prey = (self.trail_prey + [self.prey])[-8:]
        self.prey = new
        old = self.mask
        self.mask = self.model.eat(new, self.mask)
        if self.mask != old:
            self.say("Prey ate cheese! (%d left)" % len(self.model.remaining(self.mask)))
        self.decision, self.decided, self.timer = None, False, 0
        if self.prey == self.pred:
            self.end("LOSE" if self.human else "WIN", "caught")
        elif self.mask == 0:
            self.end("WIN" if self.human else "LOSE", "cheese")
        else:
            self.state = "PRED"

    def apply_pred(self, new):
        self.trail_pred = (self.trail_pred + [self.pred])[-8:]
        self.pred = new
        self.pred_moves += 1
        self.decision, self.decided, self.timer = None, False, 0
        if self.prey == self.pred:
            self.end("LOSE" if self.human else "WIN", "caught")
            return
        self.turn += 1
        if self.turn > MAX_TURNS:
            self.end("WIN" if self.human else "LOSE", "time")
        else:
            self.state = "PREY"

    def end(self, state, why):
        self.state = state
        if self.human:
            texts = {"caught": "YOU LOSE: the AI predator caught you!",
                     "cheese": "YOU WIN: you ate all the cheese!",
                     "time": "YOU WIN: you survived all %d turns!" % MAX_TURNS}
        else:
            texts = {"caught": "PREDATOR AI WINS: the prey was caught!",
                     "cheese": "PREY AI WINS: all cheese eaten!",
                     "time": "PREY AI WINS: it survived all %d turns!" % MAX_TURNS}
        self.message = texts[why]
        self.say(self.message)

    # ------------------------------------------------------------------ the AI
    def think(self, side):
        depth = self.pred_depth if side == "pred" else self.prey_depth
        res = self.model.choose(self.pred, self.prey, self.mask, depth, side,
                                self.prune, self.pred_moves)
        res["side"] = side
        self.decision, self.decided, self.timer = res, True, 0
        if side == "pred":
            self.stats = res
            kind = "SPRINT" if self.sprint_next() else "normal"
            self.say("Cat (%s): best value %d, %d nodes, %d pruned" %
                     (kind, res["value"], res["nodes"], res["cutoffs"]))

    def update(self, dt):
        if self.state in ("WIN", "LOSE"):
            return
        if self.state == "PRED":
            if not self.decided:
                self.think("pred")
            self.timer += dt
            if self.timer >= self.delay:
                self.apply_pred(self.decision["move"])
        elif self.state == "PREY" and not self.human:
            if not self.decided:
                self.think("prey")
            self.timer += dt
            if self.timer >= self.delay:
                self.apply_prey(self.decision["move"])

    # ----------------------------------------------------------- user input
    def human_move(self, dr, dc):
        if self.state != "PREY" or not self.human:
            return
        r, c = self.cell(self.prey)
        target = (r + dr, c + dc)
        if (dr, dc) == (0, 0):
            self.apply_prey(self.prey)
        elif target in self.model.index:
            self.apply_prey(self.model.index[target])

    def on_key(self, key):
        if key in KEY_DIRS:
            self.human_move(*KEY_DIRS[key])
        elif key == pygame.K_SPACE:
            self.human_move(0, 0)
        elif key == pygame.K_m:
            self.human = not self.human
            self.reset()
        elif key == pygame.K_p:
            self.prune = not self.prune
            self.say("Alpha-beta pruning: " + ("ON" if self.prune else "OFF"))
        elif key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
            self.pred_depth = min(8, self.pred_depth + 1)
        elif key in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self.pred_depth = max(1, self.pred_depth - 1)
        elif key == pygame.K_t:
            self.delay = {420: 150, 150: 800, 800: 420}.get(self.delay, 420)
        elif key == pygame.K_r:
            self.new_map()
        elif key == pygame.K_n:
            self.reset()
        elif key == pygame.K_F12 or key == pygame.K_c:
            self.screenshot()

    def screenshot(self):
        os.makedirs(SHOT_DIR, exist_ok=True)
        name = time.strftime("predator_prey_%Y%m%d_%H%M%S.png")
        pygame.image.save(self.screen, os.path.join(SHOT_DIR, name))
        self.say("Screenshot saved: screenshots/" + name)

    # ---------------------------------------------------------------- drawing
    @staticmethod
    def px(cell):
        return (cell[1] * TILE, cell[0] * TILE)

    @staticmethod
    def center(cell):
        return (cell[1] * TILE + TILE // 2, cell[0] * TILE + TILE // 2)

    def text(self, font, s, x, y, color=C_TEXT):
        self.screen.blit(font.render(s, True, color), (x, y))

    def wrap(self, font, s, x, y, width, color=C_DIM, line_h=16, max_lines=99):
        words, line, lines = s.split(), "", []
        for w in words:
            test = (line + " " + w).strip()
            if font.size(test)[0] <= width:
                line = test
            else:
                lines.append(line)
                line = w
        lines.append(line)
        for ln in lines[:max_lines]:
            self.text(font, ln, x, y, color)
            y += line_h
        return y

    def draw(self):
        scr = self.screen
        scr.fill(C_BG)
        self.draw_map()
        self.draw_panel()
        self.draw_bar()
        if self.state in ("WIN", "LOSE"):
            scr.blit(self.banner, (0, MAP_H // 2 - 75))
            col = C_GOOD if self.state == "WIN" else C_BAD
            title = "YOU WIN!" if (self.human and self.state == "WIN") else \
                    "YOU LOSE" if self.human else \
                    "PREY WINS" if self.state == "LOSE" else "PREDATOR WINS"
            surf = self.f_big.render(title, True, col)
            scr.blit(surf, (MAP_W // 2 - surf.get_width() // 2, MAP_H // 2 - 58))
            sub = self.f_norm.render(self.message, True, C_TEXT)
            scr.blit(sub, (MAP_W // 2 - sub.get_width() // 2, MAP_H // 2 + 6))
            sub2 = self.f_small.render("R = new map     N = restart     M = switch mode", True, C_DIM)
            scr.blit(sub2, (MAP_W // 2 - sub2.get_width() // 2, MAP_H // 2 + 34))
        pygame.display.flip()

    def draw_map(self):
        scr = self.screen
        for r in range(ROWS):
            for c in range(COLS):
                x, y = c * TILE, r * TILE
                if (r, c) in self.walls:
                    if self.img["floor"] is not None:
                        scr.blit(self.img["floor"], (x, y))
                    else:
                        pygame.draw.rect(scr, (236, 222, 190), (x, y, TILE, TILE))
                    if self.img["crate"] is not None:
                        scr.blit(self.img["crate"], (x, y))
                    else:
                        pygame.draw.rect(scr, (140, 95, 50), (x + 3, y + 3, TILE - 6, TILE - 6))
                else:
                    if self.img["floor"] is not None:
                        scr.blit(self.img["floor"], (x, y))
                    else:
                        pygame.draw.rect(scr, (236, 222, 190), (x, y, TILE, TILE))
                    if (r + c) % 2:
                        scr.blit(self.ov_alt, (x, y))
        scr.blit(self.grid_surf, (0, 0))

        pred_c, prey_c = self.cell(self.pred), self.cell(self.prey)

        # cheese
        for ch in self.model.remaining(self.mask):
            x, y = self.px(self.cell(ch))
            if self.img["cheese"] is not None:
                scr.blit(self.img["cheese"], (x, y))
            else:
                pygame.draw.circle(scr, (250, 205, 45), (x + TILE // 2, y + TILE // 2), TILE // 3)

        # danger zone: where the cat can reach on its NEXT move
        if self.state in ("PREY", "PRED") and self.pred is not None:
            options = self.model.sprint_moves[self.pred] if self.sprint_next() else self.model.moves[self.pred]
            for i in options:
                scr.blit(self.ov_danger, self.px(self.cell(i)))

        # trails
        for i, cell in enumerate(self.trail_pred):
            pygame.draw.circle(scr, C_PRED, self.center(self.cell(cell)), 3 + i // 3)
        for i, cell in enumerate(self.trail_prey):
            pygame.draw.circle(scr, C_PREY, self.center(self.cell(cell)), 3 + i // 3)

        # the AI's candidate moves (what Minimax is considering)
        d = self.decision
        if d is not None:
            for cell, val in d["scores"].items():
                x, y = self.px(self.cell(cell))
                scr.blit(self.ov_best if cell == d["move"] else self.ov_cand, (x, y))
                label = "WIN" if val >= 9000 else "LOSE" if val <= -9000 else str(val)
                self.text(self.f_tag, label, x + 3, y + TILE - 16, (20, 20, 20))
            origin = self.center(pred_c if d["side"] == "pred" else prey_c)
            dest = self.center(self.cell(d["move"]))
            if origin != dest:
                pygame.draw.line(scr, (20, 160, 70), origin, dest, 4)
                pygame.draw.circle(scr, (20, 160, 70), dest, 6)

        # characters
        for who, cell in (("pred", pred_c), ("prey", prey_c)):
            x, y = self.px(cell)
            if self.img[who] is not None:
                scr.blit(self.img[who], (x, y))
            else:
                pygame.draw.circle(scr, C_PRED if who == "pred" else C_PREY,
                                   (x + TILE // 2, y + TILE // 2), TILE // 2 - 4)
        px_, py_ = self.px(pred_c)
        if self.sprint_next() and self.state in ("PREY", "PRED"):
            self.text(self.f_tag, "SPRINT!", px_ + 2, py_ - 12, (255, 60, 60))

    def draw_panel(self):
        scr = self.screen
        x0 = MAP_W
        pygame.draw.rect(scr, C_PANEL, (x0, 0, PANEL_W, HEIGHT))
        x = x0 + 14
        self.text(self.f_title, "AI PREDATOR & PREY", x, 10, C_ACCENT)
        mode = "You = Mouse   |   AI = Cat" if self.human else "AI Cat  vs  AI Mouse"
        self.text(self.f_small, "Mode: " + mode, x, 38, C_TEXT)
        self.text(self.f_small, "Cat agent: Minimax + Alpha-Beta Pruning", x, 56, C_GOOD)
        self.text(self.f_small, "Search depth: %d plies    Pruning: %s" %
                  (self.pred_depth, "ON" if self.prune else "OFF"), x, 74, C_TEXT)

        y = 100
        rows = [("Turn", "%d / %d" % (min(self.turn, MAX_TURNS), MAX_TURNS)),
                ("Cheese eaten", "%d / %d" % (self.n_cheese - len(self.model.remaining(self.mask)), self.n_cheese)),
                ("Cat distance to mouse", str(self.model.dist[self.pred][self.prey])),
                ("Cat next move", "SPRINT (2 cells)" if self.sprint_next() else "normal (1 cell)")]
        for k, v in rows:
            self.text(self.f_small, k + ":", x, y, C_DIM)
            self.text(self.f_small, v, x + 160, y, C_TEXT)
            y += 18

        y += 6
        self.text(self.f_norm, "Last Minimax search", x, y, C_ACCENT)
        y += 22
        if self.stats:
            s = self.stats
            for k, v in [("Nodes visited", s["nodes"]), ("Branches pruned", s["cutoffs"]),
                         ("Best score", s["value"]), ("Time (ms)", "%.1f" % s["ms"])]:
                self.text(self.f_small, k + ":", x, y, C_DIM)
                self.text(self.f_small, str(v), x + 160, y, C_TEXT)
                y += 18
        else:
            self.text(self.f_small, "(waiting for the cat's first move)", x, y, C_DIM)
            y += 18

        y += 6
        self.text(self.f_norm, "Log", x, y, C_ACCENT)
        y += 22
        for line in self.log[-6:]:
            if y > 345:
                break
            y = self.wrap(self.f_small, line, x, y, PANEL_W - 26, C_TEXT, 15, 2)

        y = 360
        self.text(self.f_norm, "Controls", x, y, C_ACCENT)
        y += 22
        for line in ["Arrows / WASD: move mouse   SPACE: wait",
                     "M: Human vs AI  <->  AI vs AI",
                     "P: alpha-beta ON/OFF   + / -: depth",
                     "T: AI speed   R: new map   N: restart",
                     "C: save screenshot   ESC: quit"]:
            self.text(self.f_small, line, x, y, C_DIM)
            y += 17

        y += 8
        self.text(self.f_norm, "Legend", x, y, C_ACCENT)
        y += 22
        for color, label in [((90, 220, 120), "cat's chosen move"),
                             ((255, 140, 60), "other moves the cat considered"),
                             ((255, 60, 60), "danger zone (cat can reach)")]:
            pygame.draw.rect(scr, color, (x, y + 2, 14, 12))
            self.text(self.f_small, label, x + 22, y, C_DIM)
            y += 17
        self.text(self.f_small, "Numbers = Minimax score (high = good for cat)", x, y + 3, C_DIM)

    def draw_bar(self):
        scr = self.screen
        pygame.draw.rect(scr, (18, 20, 28), (0, MAP_H, MAP_W, BAR_H))
        if self.state == "WIN":
            msg, col = "RESULT: " + self.message, C_GOOD
        elif self.state == "LOSE":
            msg, col = "RESULT: " + self.message, C_BAD
        elif self.state == "PRED":
            msg, col = "Cat AI is searching the game tree (Minimax, depth %d) ..." % self.pred_depth, C_PRED
        elif self.human:
            msg, col = "Your turn - move the mouse (arrows / WASD). Avoid the red zone!", C_PREY
        else:
            msg, col = "Mouse AI is searching the game tree ...", C_PREY
        self.text(self.f_norm, msg, 12, MAP_H + 8, col)
        self.text(self.f_small, "Map seed: %d   |   Goal: cat catches mouse  /  mouse eats all cheese" % self.seed,
                  12, MAP_H + 34, C_DIM)


def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("AI Predator & Prey - Minimax with Alpha-Beta Pruning")
    try:
        pygame.display.set_icon(pygame.image.load(os.path.join(ASSET_DIR, "icon.png")))
    except Exception:
        pass
    clock = pygame.time.Clock()
    game = PredatorPreyGame(screen)

    running = True
    while running:
        dt = clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                else:
                    game.on_key(event.key)
        game.update(dt)
        game.draw()
    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
